<?php
global $page_title, $page_link;
$page_title = "Furniture Assembly Services";
$page_link = basename(__FILE__);
include_once('includes/header.php');
?>
    <main>
        <div class="sr-only"><h1>Services</h1></div>

        <section class="banner-container">
            <div id="homeSlider" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#homeSlider" data-slide-to="0" class="active"></li>
                    <li data-target="#homeSlider" data-slide-to="1"></li>
                    <li data-target="#homeSlider" data-slide-to="2"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <a href="#">
                            <img src="images/slider/we-move-and-clean-slider-2.jpg" class="img-responsive respond">
                        </a>
                    </div>
                    <div class="item">
                        <a href="#">
                            <img src="images/slider/we-move-and-clean-slider-1.jpg" class="img-responsive respond">
                        </a>
                    </div>
                </div>

                <!-- Left and right controls -->
                <a class="left carousel-control" href="#homeSlider" role="button" data-slide="prev">
                    <i class="fa fa-angle-left"></i>
                </a>
                <a class="right carousel-control" href="#homeSlider" role="button" data-slide="next">
                    <i class="fa fa-angle-right"></i>
                </a>
            </div>
        </section>

        <section class="content-container">
            <div class="row">
                <div class="col-md-6">
                    <img src="http://placehold.it/450x350" class="img-responsive respond"
                         alt="We Move & Clean - Service">
                </div>
                <div class="col-md-6">
                    <p><strong>Furniture Assembly</strong> Pellentesque habitant morbi tristique senectus sed netus males uada fames
                        ac turpis egestas aenu
                        ean non tell Donec pede qua placerat ristique faucibus poserw ulet elobortis
                        justo.<br/><br/>

                        Etiam nunc sit. Fusce non pede non erat varius lacinia unc ligula. Duis euduisemper
                        ant euismod
                        viverra. Nam etyw ant etiam sed ipsum.Donec sit amet nis In viverra dolor non justo.
                        Integer
                        velit mil facilisis egety volutpat et aliquam sed magna sed non. Lorem ipsum dolor
                        sit amet
                        consectetur.</p>

                    <div class="contact-btn">
                        <a href="#service-collapse" class="btn" data-toggle="collapse">Get A Quote</a>
                    </div>

                </div>
            </div>
        </section>

        <section class="content-container collapse" id="service-collapse">
            <form id="contact_form" method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6">
                        <div class="serviceFormBox">
                            <div class="serviceFormBox__title">
                                <h3><span class="greenIcon"><i class="fa fa-calendar"></i></span>Date</h3>
                            </div>
                            <div class="serviceFormBox__content">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>From</label>
                                            <input type="date" class="form-control required" id="from_date"
                                                   name="from_date">
                                            <span id="from_date_error" class="error">From date is required</span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>To</label>
                                            <input type="date" class="form-control required" id="to_date"
                                                   name="to_date">
                                            <span id="to_date_error" class="error">To date is required</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="serviceFormBox">
                            <div class="serviceFormBox__title">
                                <h3><span class="greenIcon"><i class="fa fa-calendar"></i></span>Time</h3>
                            </div>
                            <div class="serviceFormBox__content">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>From</label>
                                            <select class="form-control" id="from_time" name="from_time">
                                                <option value="6.00">6.00</option>
                                                <option value="6.30">6.30</option>
                                                <option value="7.00">7.00</option>
                                                <option value="7.30">7.30</option>
                                                <option value="8.00">8.00</option>
                                                <option value="8.30">8.30</option>
                                                <option value="9.00">9.00</option>
                                                <option value="9.30">9.30</option>
                                                <option value="10.00">10.00</option>
                                                <option value="10.30">10.30</option>
                                                <option value="11.00">11.00</option>
                                                <option value="11.30">11.30</option>
                                                <option value="12.00">12.00</option>
                                                <option value="12.30">12.30</option>
                                                <option value="13.00">13.00</option>
                                                <option value="13.30">13.30</option>
                                                <option value="14.00">14.00</option>
                                                <option value="14.30">14.30</option>
                                                <option value="15.00">15.00</option>
                                                <option value="15.30">15.30</option>
                                                <option value="16.00">16.00</option>
                                                <option value="16.30">16.30</option>
                                                <option value="17.00">17.00</option>
                                                <option value="17.30">17.30</option>
                                                <option value="18.00">18.00</option>
                                                <option value="18.30">18.30</option>
                                                <option value="19.00">19.00</option>
                                                <option value="19.30">19.30</option>
                                                <option value="20.00">20.00</option>
                                                <option value="20.30">20.30</option>
                                                <option value="21.00">21.00</option>
                                                <option value="21.30">21.30</option>
                                                <option value="22.00">22.00</option>
                                                <option value="22.30">22.30</option>
                                                <option value="23.00">23.00</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>To</label>
                                            <select class="form-control" id="to_time" name="to_time">
                                                <option value="6.00">6.00</option>
                                                <option value="6.30">6.30</option>
                                                <option value="7.00">7.00</option>
                                                <option value="7.30">7.30</option>
                                                <option value="8.00">8.00</option>
                                                <option value="8.30">8.30</option>
                                                <option value="9.00">9.00</option>
                                                <option value="9.30">9.30</option>
                                                <option value="10.00">10.00</option>
                                                <option value="10.30">10.30</option>
                                                <option value="11.00">11.00</option>
                                                <option value="11.30">11.30</option>
                                                <option value="12.00">12.00</option>
                                                <option value="12.30">12.30</option>
                                                <option value="13.00">13.00</option>
                                                <option value="13.30">13.30</option>
                                                <option value="14.00">14.00</option>
                                                <option value="14.30">14.30</option>
                                                <option value="15.00">15.00</option>
                                                <option value="15.30">15.30</option>
                                                <option value="16.00">16.00</option>
                                                <option value="16.30">16.30</option>
                                                <option value="17.00">17.00</option>
                                                <option value="17.30">17.30</option>
                                                <option value="18.00">18.00</option>
                                                <option value="18.30">18.30</option>
                                                <option value="19.00">19.00</option>
                                                <option value="19.30">19.30</option>
                                                <option value="20.00">20.00</option>
                                                <option value="20.30">20.30</option>
                                                <option value="21.00">21.00</option>
                                                <option value="21.30">21.30</option>
                                                <option value="22.00">22.00</option>
                                                <option value="22.30">22.30</option>
                                                <option value="23.00">23.00</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="serviceFormBox">
                            <div class="serviceFormBox__title">
                                <h3><span class="greenIcon"><i class="fa fa-user"></i></span>Personal Info</h3>
                            </div>
                            <div class="serviceFormBox__content">
                                <div class="row">
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Title</label>
                                            <select class="form-control valid" id="title" name="title">
                                                <option value="Mr">Mr</option>
                                                <option value="Mrs">Mrs</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Name</label>
                                            <input type="text" class="form-control" id="name" name="name">
                                            <span id="name_error" class="error">Name is required</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Email <span class="red">*</span></label>
                                            <input type="text" class="form-control required" id="email" name="email">
                                            <span id="email_error" class="error">Email is required</span>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Contact Number</label>
                                            <input type="text" class="form-control" id="contact_number"
                                                   name="contact_number">
                                            <span id="contact_number_error"
                                                  class="error">Contact Number is required</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="serviceFormBox">
                            <div class="serviceFormBox__title">
                                <h3><span class="greenIcon"><i class="fa fa-truck"></i></span>Collection Info</h3>
                            </div>
                            <div class="serviceFormBox__content">
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label>Property number and street name</label>
                                            <input type="text" class="form-control" id="pty_number" name="pty_number">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Postcode <span class="red">*</span></label>
                                            <input type="text" class="form-control required" id="postcode"
                                                   name="postcode">
                                            <span id="postcode_error" class="error">Postcode is required</span>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Parking <span class="red">*</span></label>
                                            <select class="form-control required" id="collection_parking"
                                                    name="collection_parking">
                                                <option value="">--- Select ---</option>
                                                <option value="Driveway">Driveway</option>
                                                <option value="Street (same side as the property)">Street (same side as
                                                    the property)
                                                </option>
                                                <option value="Street (opposite side to the property)">Street (opposite
                                                    side to the property)
                                                </option>
                                            </select>
                                            <span class="error">Collection parking is required</span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Distance from the door <span class="red">*</span></label>
                                            <select class="form-control required" id="collection_door_distance"
                                                    name="collection_door_distance">
                                                <option value="">--- Select ---</option>
                                                <option value="Less than 16 feet (5 meters)">Less than 16 feet (5
                                                    meters)
                                                </option>
                                                <option value="Less than 50 feet (15 meters)">Less than 50 feet (15
                                                    meters)
                                                </option>
                                                <option value="Less than 100 feet (30 meters)">Less than 100 feet (30
                                                    meters)
                                                </option>
                                            </select>
                                            <span class="error">Collection door distance is required</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label>Property type <span class="red">*</span></label>
                                                    <select class="form-control required" id="collection_pty_type"
                                                            name="collection_pty_type" data-toggle_field="true" data-fields="#collection_flat_hidden">
                                                        <option value="">--- Select ---</option>
                                                        <option value="Bungalow">Bungalow</option>
                                                        <option value="">-------</option>
                                                        <option value="1 bed house">1 bed house</option>
                                                        <option value="2 bed house">2 bed house</option>
                                                        <option value="3 bed house">3 bed house</option>
                                                        <option value="4 bed house">4 bed house</option>
                                                        <option value="">------------</option>
                                                        <option value="Studioflat">Studio flat</option>
                                                        <option value="1bedflat">1 bed flat</option>
                                                        <option value="2bedflat">2 bed flat</option>
                                                        <option value="3bedflat">3 bed flat</option>
                                                        <option value="4bedflat">4 bed flat</option>
                                                    </select>
                                                    <span class="error">Collection property type is required</span>
                                                </div>
                                                <div class="col-md-6">
                                                    <div id="collection_flat_hidden" class="soft-hide">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="collection_floor_number">Floor <span class="red">*</span></label>
                                                                <select class="form-control required" id="collection_floor_number"
                                                                        name="collection_floor_number">
                                                                    <option value="">--- Select ---</option>
                                                                    <option value="ground">Ground</option>
                                                                    <option value="1">1</option>
                                                                    <option value="2">2</option>
                                                                    <option value="3">3</option>
                                                                    <option value="4">4</option>
                                                                    <option value="5">5</option>
                                                                    <option value="6">6</option>
                                                                    <option value="7">7</option>
                                                                    <option value="8">8</option>
                                                                    <option value="9">9</option>

                                                                </select>
                                                                <span class="error">Floor field is required.</span>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="collection_lift">Access to lift <span class="red">*</span></label>
                                                                <select class="form-control required" id="collection_lift"
                                                                        name="collection_lift">
                                                                    <option value="">--- Select ---</option>
                                                                    <option value="Yes">Yes</option>
                                                                    <option value="No">No</option>

                                                                </select>
                                                                <span class="error">Floor field is required.</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="serviceFormBox">
                            <div class="serviceFormBox__title">
                                <h3><span class="greenIcon"><i class="fa fa-truck"></i></span>Delivery Info</h3>
                            </div>
                            <div class="serviceFormBox__content">
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label>Property number and street name</label>
                                            <input type="text" class="form-control" id="pty_number" name="pty_number">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Postcode <span class="red">*</span></label>
                                            <input type="text" class="form-control required" id="postcode"
                                                   name="postcode">
                                            <span id="postcode_error" class="error">Postcode is required</span>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Parking <span class="red">*</span></label>
                                            <select class="form-control required" id="delivery_parking"
                                                    name="delivery_parking">
                                                <option value="">--- Select ---</option>
                                                <option value="Driveway">Driveway</option>
                                                <option value="Street (same side as the property)">Street (same side as
                                                    the property)
                                                </option>
                                                <option value="Street (opposite side to the property)">Street (opposite
                                                    side to the property)
                                                </option>
                                            </select>
                                            <span class="error">Delivery parking is required</span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Distance from the door <span class="red">*</span></label>
                                            <select class="form-control required" id="delivery_door_distance"
                                                    name="delivery_door_distance">
                                                <option value="">--- Select ---</option>
                                                <option value="Less than 16 feet (5 meters)">Less than 16 feet (5
                                                    meters)
                                                </option>
                                                <option value="Less than 50 feet (15 meters)">Less than 50 feet (15
                                                    meters)
                                                </option>
                                                <option value="Less than 100 feet (30 meters)">Less than 100 feet (30
                                                    meters)
                                                </option>
                                            </select>
                                            <span class="error">Delivery door distance is required</span>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label>Property type <span class="red">*</span></label>
                                                    <select class="form-control required" id="delivery_pty_type"
                                                            name="delivery_pty_type" data-toggle_field="true" data-fields="#delivery_flat_hidden">
                                                        <option value="">--- Select ---</option>
                                                        <option value="Bungalow">Bungalow</option>
                                                        <option value="">-------</option>
                                                        <option value="1 bed house">1 bed house</option>
                                                        <option value="2 bed house">2 bed house</option>
                                                        <option value="3 bed house">3 bed house</option>
                                                        <option value="4 bed house">4 bed house</option>
                                                        <option value="">------------</option>
                                                        <option value="Studio flat">Studio flat</option>
                                                        <option value="1 bed flat">1 bed flat</option>
                                                        <option value="2 bed flat">2 bed flat</option>
                                                        <option value="3 bed flat">3 bed flat</option>
                                                        <option value="4 bed flat">4 bed flat</option>
                                                    </select>
                                                    <span class="error">Delivery property type is required</span>
                                                </div>
                                                <div class="col-md-6">
                                                    <div id="delivery_flat_hidden" class="soft-hide">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="delivery_floor_number">Floor <span class="red">*</span></label>
                                                                <select class="form-control required" id="delivery_floor_number"
                                                                        name="delivery_floor_number">
                                                                    <option value="">--- Select ---</option>
                                                                    <option value="ground">Ground</option>
                                                                    <option value="1">1</option>
                                                                    <option value="2">2</option>
                                                                    <option value="3">3</option>
                                                                    <option value="4">4</option>
                                                                    <option value="5">5</option>
                                                                    <option value="6">6</option>
                                                                    <option value="7">7</option>
                                                                    <option value="8">8</option>
                                                                    <option value="9">9</option>

                                                                </select>
                                                                <span class="error">Floor field is required.</span>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="delivery_lift">Access to lift <span class="red">*</span></label>
                                                                <select class="form-control required" id="delivery_lift"
                                                                        name="delivery_lift">
                                                                    <option value="">--- Select ---</option>
                                                                    <option value="Yes">Yes</option>
                                                                    <option value="No">No</option>

                                                                </select>
                                                                <span class="error">Floor field is required.</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="serviceFormBox">
                            <div class="serviceFormBox__title">
                                <h3><span class="greenIcon"><i class="fa fa-th-list"></i></span>List of inventory</h3>
                                <span id="img_check_error" class="error">You must select at least one room</span>
                            </div>
                            <div class="serviceFormBox__content serviceFormBox__content--alt">
                                <div class="imgCheckList" id="rooms_list">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="imgCheck center">
                                                <h4>Kitchen</h4>
                                                <label for="kitchen"><img src="images/quote-imgs/kitchen.jpg"
                                                                          class="img-responsive"></label>
                                                <div class="center">
                                                    Are you taking any white goods from your kitchen ?
                                                    <br/>
                                                    <input type="checkbox" class="toggle" id="kitchen"
                                                           name="kitchen_room">
                                                    <label for="kitchen"><span>Yes</span><span>No</span></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="imgCheck center">
                                                <h4>Living Room</h4>
                                                <label for="living_room"><img src="images/quote-imgs/living_room.jpg"
                                                                              class="img-responsive"></label>
                                                <div class="center">
                                                    Are you taking any furniture from your living room?
                                                    <br/>
                                                    <input type="checkbox" class="toggle" id="living_room"
                                                           name="living_room">
                                                    <label for="living_room"><span>Yes</span><span>No</span></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="imgCheck center">
                                                <h4>Dining Room</h4>
                                                <label for="dining_room"><img src="images/quote-imgs/dining_room.jpg"
                                                                              class="img-responsive"></label>
                                                <div class="center">
                                                    Are you taking any furniture from your dining Room?
                                                    <br/>
                                                    <input type="checkbox" class="toggle" id="dining_room"
                                                           name="dining_room">
                                                    <label for="dining_room"><span>Yes</span><span>No</span></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="imgCheck center">
                                                <h4>Garden / Shed</h4>
                                                <label for="garden-shed"><img src="images/quote-imgs/garden_shed.jpg"
                                                                              class="img-responsive"></label>
                                                <div class="center">
                                                    Are you taking any items form your garden / shed?
                                                    <br/>
                                                    <input type="checkbox" class="toggle" id="garden-shed"
                                                           name="bathroom">
                                                    <label for="garden-shed"><span>Yes</span><span>No</span></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="imgCheck center">
                                                <h4>1st Bedroom</h4>
                                                <label for="first_bedroom"><img src="images/quote-imgs/bedroom.jpg"
                                                                                class="img-responsive"></label>
                                                <div class="center">
                                                    Are you taking any furniture from your 1st bedroom?
                                                    <br/>
                                                    <input type="checkbox" class="toggle" id="first_bedroom"
                                                           name="first_bedroom">
                                                    <label for="first_bedroom"><span>Yes</span><span>No</span></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="imgCheck center">
                                                <h4>2nd Bedroom</h4>
                                                <label for="second_bedroom"><img src="images/quote-imgs/bedroom.jpg"
                                                                                 class="img-responsive"></label>
                                                <div class="center">
                                                    Are you taking any furniture from your 2nd bedroom?
                                                    <br/>
                                                    <input type="checkbox" class="toggle" id="second_bedroom"
                                                           name="second_bedroom">
                                                    <label for="second_bedroom"><span>Yes</span><span>No</span></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="imgCheck center">
                                                <h4>3rd Bedroom</h4>
                                                <label for="third_bedroom"><img src="images/quote-imgs/bedroom.jpg"
                                                                                class="img-responsive"></label>
                                                <div class="center">
                                                    Are you taking any furniture from your 3rd bedroom?<br/>
                                                    <input type="checkbox" class="toggle" id="third_bedroom"
                                                           name="third_bedroom">
                                                    <label for="third_bedroom"><span>Yes</span><span>No</span></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="imgCheck center">
                                                <h4>4th Bedroom</h4>
                                                <label for="fourth_bedroom"><img src="images/quote-imgs/bedroom.jpg"
                                                                                 class="img-responsive"></label>
                                                <div class="center">
                                                    Are you taking any furniture from your 4th bedroom?
                                                    <br/>
                                                    <input type="checkbox" class="toggle" id="fourth_bedroom"
                                                           name="fourth_bedroom">
                                                    <label for="fourth_bedroom"><span>Yes</span><span>No</span></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="imgCheck center">
                                                <h4>Conservatory Room</h4>
                                                <label for="conservatory_room"><img
                                                        src="images/quote-imgs/conservatory_room.jpg"
                                                        class="img-responsive"></label>
                                                <div class="center">
                                                    Are you taking any furniture from your
                                                    conservatory?<br/>
                                                    <input type="checkbox" class="toggle" id="conservatory_room"
                                                           name="conservatory_room">
                                                    <label
                                                        for="conservatory_room"><span>Yes</span><span>No</span></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="imgCheck center">
                                                <h4>Garage</h4>
                                                <label for="garage"><img
                                                        src="images/quote-imgs/garage.jpg"
                                                        class="img-responsive"></label>
                                                <div class="center">
                                                    Are you taking any items from your garage?<br/>
                                                    <input type="checkbox" class="toggle" id="garage"
                                                           name="garage">
                                                    <label
                                                        for="garage"><span>Yes</span><span>No</span></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="imgCheck center">
                                                <h4>Loft</h4>
                                                <label for="loft"><img
                                                        src="images/quote-imgs/loft.jpg"
                                                        class="img-responsive"></label>
                                                <div class="center">
                                                    Are you taking any items from your loft?<br/>
                                                    <input type="checkbox" class="toggle" id="loft"
                                                           name="loft">
                                                    <label
                                                        for="loft"><span>Yes</span><span>No</span></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="imgCheck center">
                                                <h4>Basement</h4>
                                                <label for="basement"><img
                                                        src="images/quote-imgs/basement.jpg"
                                                        class="img-responsive"></label>
                                                <div class="center">
                                                    Are you taking any items from your basement?<br/>
                                                    <input type="checkbox" class="toggle" id="basement"
                                                           name="basement">
                                                    <label
                                                        for="basement"><span>Yes</span><span>No</span></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="imgCheck center">
                                                <h4>Lounge</h4>
                                                <label for="lounge"><img src="images/quote-imgs/lounge.jpg"
                                                                         class="img-responsive"></label>
                                                <div class="center">
                                                    Are you taking any furniture from your lounge?<br/>
                                                    <input type="checkbox" class="toggle" id="lounge"
                                                           name="lounge_room">
                                                    <label for="lounge"><span>Yes</span><span>No</span></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="imgCheck center">
                                                <h4>1st Box / Storage Room</h4>
                                                <label for="first_box_storage_room"><img
                                                        src="images/quote-imgs/box_storage_room.jpg"
                                                        class="img-responsive"></label>
                                                <div class="center">
                                                    Are you taking any furniture from your 1st Box / Storage
                                                    room?<br/>
                                                    <input type="checkbox" class="toggle" id="first_box_storage_room"
                                                           name="first_box_storage_room">
                                                    <label
                                                        for="first_box_storage_room"><span>Yes</span><span>No</span></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="imgCheck center">
                                                <h4>2nd Box / Storage Room</h4>
                                                <label for="second_box_storage_room"><img
                                                        src="images/quote-imgs/box_storage_room.jpg"
                                                        class="img-responsive"></label>
                                                <div class="center">
                                                    Are you taking any furniture from your 2nd Box / Storage
                                                    room?<br/>
                                                    <input type="checkbox" class="toggle" id="second_box_storage_room"
                                                           name="second_box_storage_room">
                                                    <label
                                                        for="second_box_storage_room"><span>Yes</span><span>No</span></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="imgCheck center">
                                                <h4>3rd Box / Storage Room</h4>
                                                <label for="third_box_storage_room"><img
                                                        src="images/quote-imgs/box_storage_room.jpg"
                                                        class="img-responsive"></label>
                                                <div class="center">
                                                    Are you taking any furniture from your 3rd Box / Storage
                                                    room?<br/>
                                                    <input type="checkbox" class="toggle" id="third_box_storage_room"
                                                           name="third_box_storage_room">
                                                    <label
                                                        for="third_box_storage_room"><span>Yes</span><span>No</span></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="other_rooms">Please point out any other room which is not listed
                                            above:</label>
                                            <textarea id="other_rooms" name="other_rooms"
                                                      class="form-control"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="serviceFormBox">
                            <div class="serviceFormBox__title">
                                <h3><span class="greenIcon"><i class="fa fa-wrench"></i></span>Furniture Dismantling and
                                    Assembly</h3>
                            </div>
                            <div class="serviceFormBox__content">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <p>Does any furniture need dismantling?</p>
                                                <input type="checkbox" class="toggle"
                                                       id="qut_furniture_need_dismantling"
                                                       name="qut_furniture_need_dismantling">
                                                <label
                                                    for="qut_furniture_need_dismantling"><span>Yes</span><span>No</span></label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group" id="imgFld">
                                                    <label>Click here to add pictures</label>
                                                    <input type="file" id="qut_furniture_dismantling_pictures"
                                                           name="qut_furniture_dismantling_pictures[]"
                                                           multiple="multiple">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <p>Comments on Furniture Dismantling and Assembly</p>
                                            <textarea class="form-control" id="qut_furniture_dismantling_comments"
                                                      name="qut_furniture_dismantling_comments"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="serviceFormBox">
                            <div class="serviceFormBox__title">
                                <h3><span class="greenIcon"><i class="fa fa-wrench" aria-hidden="true"></i></span>Packing
                                    and Unpacking Service
                                </h3>
                            </div>
                            <div class="serviceFormBox__content">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="packing_service">Would you like to add Packing Service?</label>
                                            <input type="checkbox" class="toggle"
                                                   id="packing_service"
                                                   name="packing_service">
                                            <label
                                                for="packing_service"><span>Yes</span><span>No</span></label>
                                        </div>

                                        <div class="form-group">
                                            <label for="unpacking_service">Would you like to add Unpacking
                                                Service?</label>
                                            <input type="checkbox" class="toggle"
                                                   id="unpacking_service"
                                                   name="unpacking_service">
                                            <label
                                                for="unpacking_service"><span>Yes</span><span>No</span></label>
                                        </div>

                                        <div class="form-group">
                                            <label for="partial_packing_service">Would you like to add Partial Packing
                                                Service (fragile items only)?</label>
                                            <input type="checkbox" class="toggle"
                                                   id="partial_packing_service"
                                                   name="partial_packing_service">
                                            <label
                                                for="partial_packing_service"><span>Yes</span><span>No</span></label>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="serviceFormBox">
                            <div class="serviceFormBox__title">
                                <h3><span class="greenIcon"><i class="fa fa-plus"></i></span>Additional Information
                                </h3>
                            </div>
                            <div class="serviceFormBox__content">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="additional_message">Write your notes or message</label>
                                            <textarea id="additional_message" name="additional_message"
                                                      class="form-control"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <span id="mail_success" class="success">Message Sent!</span>
                        <span id="mail_fail"
                              class="error">Message failed to send. Contact the system administrator.</span>
                        <button type="submit" class="btn btn--green" id="send_message">Submit</button>
                    </div>
                </div>
            </form>
            <script type="text/javascript">
                (function ($) {
                    $(document).ready(function () {
                        $("*[data-toggle_field='true'").change(function() {
                            var $elements = $($(this).data("fields"));
                            if($(this).val().indexOf("flat") == "-1") {
                                $elements.hide().children("input, select, textarea").each(function() {
                                   $(this).prop("disabled", true);
                                });
                            } else {
                                $elements.show().children("input, select, textarea").each(function() {
                                    $(this).prop("disabled", false);
                                });
                            }
                        });


                        $('#send_message').click(function (e) {

                            e.preventDefault();

                            var error = false;
                            var form = $("#contact_form");

                            //Error messages
                            form.find("input.required, textarea.required, select.required").each(function () {
                                if ($(this).val().length == 0) {
                                    error = true;
                                    $(this).parent().addClass("has-error");
                                    $(this).siblings(".error").fadeIn(500);
                                } else {
                                    $(this).parent().removeClass("has-error");
                                    $(this).siblings(".error").fadeOut(500);
                                }
                            });

                            if (error == false) {
                                $('#send_message').attr({'disabled': 'true', 'value': 'Sending...'});

                                $.post("includes/email/send_cleaning_email.php", form.serialize(), function (result) {
                                    //Debug - coincides with the debug in the email php file
                                    //console.log(result);

                                    if (result == 'sent') {
                                        $('#mail_success').fadeIn(500);
                                    } else {
                                        $('#mail_fail').fadeIn(500);
                                        $('#send_message').removeAttr('disabled').attr('value', 'Submit');
                                    }
                                });
                            }
                        });
                    });
                }(jQuery));
            </script>
        </section>

        <section class="content-container">
            <div class="row">
                <div class="col-md-6">
                    <img src="http://placehold.it/450x350" class="img-responsive respond"
                         alt="We Move & Clean - Service">
                </div>
                <div class="col-md-6">
                    <img src="http://placehold.it/450x170" class="img-responsive respond"
                         alt="We Move & Clean - Service">
                    <br/>
                    <img src="http://placehold.it/450x170" class="img-responsive respond"
                         alt="We Move & Clean - Service">
                </div>
            </div>
        </section>

        <section class="content-container">
            <h2>What Our Clients Say</h2>
            <div id="testimonials" class="carousel carousel--testimonials slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#testimonials" data-slide-to="0" class="active"></li>
                    <li data-target="#testimonials" data-slide-to="1"></li>
                    <li data-target="#testimonials" data-slide-to="2"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <p>
                            Mauris purus elit, vestibulum ut tellus sit amet, laoreet ultrices arcu. Mauris vehicula
                            magna id diam pellentesque vulputate vel vel ligula. Sed felis justo, blandit ac fringilla
                            nec, laoreet nec diam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
                            posuere cubilia Curae; Proin in suscipit odio, id fermentum elit. Etiam mattis dui nec nibh
                            mollis dignissim. Donec id dignissim lectus, et blandit tortor. Pellentesque sed pulvinar
                            dui.
                        </p>
                    </div>
                    <div class="item">
                        <p>
                            Mauris purus elit, vestibulum ut tellus sit amet, laoreet ultrices arcu. Mauris vehicula
                            magna id diam pellentesque vulputate vel vel ligula. Sed felis justo, blandit ac fringilla
                            nec, laoreet nec diam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
                            posuere cubilia Curae; Proin in suscipit odio, id fermentum elit. Etiam mattis dui nec nibh
                            mollis dignissim. Donec id dignissim lectus, et blandit tortor. Pellentesque sed pulvinar
                            dui.
                        </p>
                    </div>
                    <div class="item">
                        <p>
                            Mauris purus elit, vestibulum ut tellus sit amet, laoreet ultrices arcu. Mauris vehicula
                            magna id diam pellentesque vulputate vel vel ligula. Sed felis justo, blandit ac fringilla
                            nec, laoreet nec diam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
                            posuere cubilia Curae; Proin in suscipit odio, id fermentum elit. Etiam mattis dui nec nibh
                            mollis dignissim. Donec id dignissim lectus, et blandit tortor. Pellentesque sed pulvinar
                            dui.
                        </p>
                    </div>
                    <div class="item">
                        <p>
                            Mauris purus elit, vestibulum ut tellus sit amet, laoreet ultrices arcu. Mauris vehicula
                            magna id diam pellentesque vulputate vel vel ligula. Sed felis justo, blandit ac fringilla
                            nec, laoreet nec diam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
                            posuere cubilia Curae; Proin in suscipit odio, id fermentum elit. Etiam mattis dui nec nibh
                            mollis dignissim. Donec id dignissim lectus, et blandit tortor. Pellentesque sed pulvinar
                            dui.
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <section class="content-container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="underline">Latest News</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4">
                    <article>
                        <h3>Article</h3>
                        <img src="images/we-move-and-clean-blog-image.png" class="img-responsive">
                        <p>
                            Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit.
                            Sed vel interdum eros. Nunc laoreet sem hendrerit diam congue, ut sagittis felis porta.
                            Proin id
                            euismod nibh, et blandit lacus. Etiam eu eros nec nunc faucibus dignissim. Aliquam congue
                            quis
                            mi eu vestibulum. Vestibulum finibus nibh et ex sodales tincidunt. Mauris dictum leo velit,
                            nec
                            condimentum sapien ornare eget.
                        </p>
                        <div class="link">
                            <a href="#">Read More</a>
                        </div>
                    </article>
                </div>
                <div class="col-md-4">
                    <article>
                        <h3>Article</h3>
                        <img src="images/we-move-and-clean-blog-image.png" class="img-responsive">
                        <p>
                            Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit.
                            Sed vel interdum eros. Nunc laoreet sem hendrerit diam congue, ut sagittis felis porta.
                            Proin id
                            euismod nibh, et blandit lacus. Etiam eu eros nec nunc faucibus dignissim. Aliquam congue
                            quis
                            mi eu vestibulum. Vestibulum finibus nibh et ex sodales tincidunt. Mauris dictum leo velit,
                            nec
                            condimentum sapien ornare eget.
                        </p>
                        <div class="link">
                            <a href="#">Read More</a>
                        </div>
                    </article>
                </div>
                <div class="col-md-4">
                    <article>
                        <h3>Article</h3>
                        <img src="images/we-move-and-clean-blog-image.png" class="img-responsive">
                        <p>
                            Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit.
                            Sed vel interdum eros. Nunc laoreet sem hendrerit diam congue, ut sagittis felis porta.
                            Proin id
                            euismod nibh, et blandit lacus. Etiam eu eros nec nunc faucibus dignissim. Aliquam congue
                            quis
                            mi eu vestibulum. Vestibulum finibus nibh et ex sodales tincidunt. Mauris dictum leo velit,
                            nec
                            condimentum sapien ornare eget.
                        </p>
                        <div class="link">
                            <a href="#">Read More</a>
                        </div>
                    </article>
                </div>
            </div>
        </section>
    </main>
<?php
include_once('includes/footer.php');
?>