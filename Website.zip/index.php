<?php
global $page_title, $page_link;
$page_title = "Home";
$page_link = basename(__FILE__);
include_once('includes/header.php');
?>
    <main>
        <div class="sr-only"><h1>Home</h1></div>

        <section class="banner-container">
            <div id="homeSlider" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#homeSlider" data-slide-to="0" class="active"></li>
                    <li data-target="#homeSlider" data-slide-to="1"></li>
                    <li data-target="#homeSlider" data-slide-to="2"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <a href="#">
                            <img src="images/slider/we-move-and-clean-slider-1.jpg" class="img-responsive respond">
                        </a>
                    </div>
                    <div class="item">
                        <a href="#">
                            <img src="images/slider/we-move-and-clean-slider-2.jpg" class="img-responsive respond">
                        </a>
                    </div>
                </div>

                <!-- Left and right controls -->
                <a class="left carousel-control" href="#homeSlider" role="button" data-slide="prev">
                    <i class="fa fa-angle-left"></i>
                </a>
                <a class="right carousel-control" href="#homeSlider" role="button" data-slide="next">
                    <i class="fa fa-angle-right"></i>
                </a>
            </div>
        </section>

        <section class="content-container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="underline">Welcome</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pharetra diam id aliquet commodo.
                        Nam
                        nec
                        sapien
                        metus. Aenean quam mauris, tincidunt quis commodo at, pharetra at nisl. Fusce cursus arcu a
                        risus
                        lobortis,
                        vitae ultricies nisi rhoncus. Donec scelerisque, neque eu rhoncus bibendum, odio urna commodo
                        dolor,
                        eu
                        ornare mauris metus eget sem. Integer imperdiet leo non enim consectetur, vel commodo tortor
                        luctus.
                        Nunc ac
                        felis maximus, tincidunt sapien non, placerat magna. Quisque ut mauris sit amet ante feugiat
                        laoreet
                        eget
                        non ligula. Praesent maximus varius urna, ut pulvinar massa pellentesque et. Pellentesque
                        egestas
                        porta
                        aliquam. Nunc ut consectetur ex.
                    </p>
                </div>
                <div class="col-md-6">
                    <p class="alt right">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pharetra diam id aliquet commodo.
                        Nam
                        nec
                        sapien metus. Aenean quam mauris, tincidunt quis commodo at, pharetra at nisl. Fusce cursus arcu
                        a
                        risus
                        lobortis, vitae ultricies nisi rhoncus. Donec scelerisque, neque eu rhoncus bibendum, odio urna
                        commodo
                        dolor, eu ornare mauris metus eget sem. Integer imperdiet leo non enim consectetur, vel commodo
                        tortor
                        luctus. Nunc ac felis maximus, tincidunt sapien non, placerat magna. Quisque ut mauris sit amet
                        ante
                        feugiat laoreet eget non ligula. Praesent maximus varius urna, ut pulvinar massa pellentesque
                        et.
                        Pellentesque egestas porta aliquam. Nunc ut consectetur ex.
                    </p>
                </div>
            </div>
        </section>

        <section class="container-full container-full--alt">
            <div class="content-container">
                <div class="row">
                    <div class="col-md-12">
                        <h2>How it Works</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="homepage-box-main homepage-box text-center">
                            <h3>Old Property?</h3>

                            <i class="fa fa-home home-icon home-icon-old" aria-hidden="true"></i>

                            <div class="row">
                                <ul class="list-unstyled">
                                    <div class="col-md-6">
                                        <li>Removals</li>
                                        <li>Packing Service</li>
                                        <li>Van & Driver Hire</li>
                                        <li>Furniture Assembly</li>
                                        <li>Crates Hire</li>
                                    </div>
                                    <div class="col-md-6">
                                        <li>Storage</li>
                                        <li>Carpet Cleaning</li>
                                        <li>End of Tenancy Cleaning</li>
                                        <li>Clearance</li>
                                    </div>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="homepage-box-main homepage-box text-center">
                            <h3>New Property?</h3>

                            <i class="fa fa-home home-icon home-icon-new" aria-hidden="true"></i>
                            <div class="row">
                                <ul class="list-unstyled">
                                    <div class="col-md-6">
                                        <li>Furniture Assembly</li>
                                        <li>Unpacking Service</li>
                                        <li>Carpet Cleaning</li>
                                        <li>Pre-Tenancy Cleaning</li>
                                        <li>One-off / Spring Cleaning</li>
                                    </div>
                                    <div class="col-md-6">
                                        <li>Domestic Cleaning</li>
                                        <li>Appliances Cleaning</li>
                                    </div>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="homepage-box text-center">
                            <h3>Bespoke</h3>

                            <h3>Get in touch, explain your requirements and leave the rest to us.</h3>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="content-container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="underline">Why Us</h2>
                </div>
            </div>

            <div class="row row--alt">
                <div class="col-md-12">
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <h2 class="underline">Areas We Cover</h2>
                    <div class="container-map">
                        <div id="map-canvas"></div>
                    </div>
                </div>
            </div>


        </section>

        <section class="content-container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="underline">Latest News</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4">
                    <article>
                        <h3>Article</h3>
                        <img src="images/we-move-and-clean-blog-image.png" class="img-responsive">
                        <p>
                            Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit.
                            Sed vel interdum eros. Nunc laoreet sem hendrerit diam congue, ut sagittis felis porta.
                            Proin id
                            euismod nibh, et blandit lacus. Etiam eu eros nec nunc faucibus dignissim. Aliquam congue
                            quis
                            mi eu vestibulum. Vestibulum finibus nibh et ex sodales tincidunt. Mauris dictum leo velit,
                            nec
                            condimentum sapien ornare eget.
                        </p>
                        <div class="link">
                            <a href="#">Read More</a>
                        </div>
                    </article>
                </div>
                <div class="col-md-4">
                    <article>
                        <h3>Article</h3>
                        <img src="images/we-move-and-clean-blog-image.png" class="img-responsive">
                        <p>
                            Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit.
                            Sed vel interdum eros. Nunc laoreet sem hendrerit diam congue, ut sagittis felis porta.
                            Proin id
                            euismod nibh, et blandit lacus. Etiam eu eros nec nunc faucibus dignissim. Aliquam congue
                            quis
                            mi eu vestibulum. Vestibulum finibus nibh et ex sodales tincidunt. Mauris dictum leo velit,
                            nec
                            condimentum sapien ornare eget.
                        </p>
                        <div class="link">
                            <a href="#">Read More</a>
                        </div>
                    </article>
                </div>
                <div class="col-md-4">
                    <article>
                        <h3>Article</h3>
                        <img src="images/we-move-and-clean-blog-image.png" class="img-responsive">
                        <p>
                            Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit.
                            Sed vel interdum eros. Nunc laoreet sem hendrerit diam congue, ut sagittis felis porta.
                            Proin id
                            euismod nibh, et blandit lacus. Etiam eu eros nec nunc faucibus dignissim. Aliquam congue
                            quis
                            mi eu vestibulum. Vestibulum finibus nibh et ex sodales tincidunt. Mauris dictum leo velit,
                            nec
                            condimentum sapien ornare eget.
                        </p>
                        <div class="link">
                            <a href="#">Read More</a>
                        </div>
                    </article>
                </div>
            </div>
        </section>
    </main>

    <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
    <script src="js/map.js"></script>
<?php
include_once('includes/footer.php');
?>