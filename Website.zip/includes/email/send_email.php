<?php
    //Debug - this will output that the form has failed every time - check the javascript console for debug
//    print_r($_POST);

    $rooms = array();

    //Split rooms from array
    foreach($_POST as $key => $value) {
        if(strpos($key, "room")) {
            $rooms[$key] = $value;
            unset($_POST[$key]);
        }
    }

    $email_to =   'cw@planalink.com';
    $email    =   $_POST['email'];
    $subject  =   $_POST['subject'];
    unset($_POST['subject']);

    $message = "";
    foreach($_POST as $key => $value) {
        $message .= ucfirst(str_replace("_", " ", $key)) . ": " . $value . "\r\n";
    }

    if(count($rooms) > 0) {
        $message .= "\r\nRooms to clean:\r\n";
        foreach ($rooms as $room => $val) {
            if ($room == "other_rooms") {
                $message .= "\tOther Rooms: \r\n" . "\t\t" . $val;
                continue;
            }
            $message .= "\t" . ucfirst(str_replace("_", " ", $room)) . "\r\n";
        }
    }

    $headers  = "From: $email\r\n";
    $headers .= "Reply-To: $email\r\n";

    if (mail($email_to, $subject, wordwrap($message, 70, "\r\n"), $headers)) {
        echo 'sent';
    } else {
        echo 'failed';
    }
