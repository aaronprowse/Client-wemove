<section class="contactBlock">
    <form class="row" id="call_back_form">
        <div class="col-md-3">
            <h4>Request A Call Back</h4>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control required" id="name" name="name">
                <span class="error">Name is required</span>
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label for="phone">Telephone</label>
                <input type="tel" class="form-control required" id="phone" name="phone">
                <span class="error">Telephone is required</span>
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label></label>
                <input type="submit" id="send_message_call_back" class="form-control footer-submit">
                <span id="mail_success_call_back" class="success">Message Sent!</span>
                <span id="mail_fail_call_back" class="error">Message failed to send. Contact the system administrator.</span>
                <span id="validation_call_back" class="error">Validation error. Please check your entries.</span>
                <input type="hidden" name="subject" value="We Move & Clean - Call Back Request">
            </div>
        </div>
    </form>
    <script type="text/javascript">
        (function ($) {
            $(document).ready(function () {
                $('#send_message_call_back').click(function (e) {

                    e.preventDefault();

                    $('#mail_success_call_back').fadeOut(500);
                    $('#mail_fail_call_back').fadeOut(500);
                    $('#validation_call_back').fadeOut(500);

                    var error = false;
                    var form = $("#call_back_form");

                    //Error messages
                    form.find("input.required, textarea.required, select.required").each(function() {
                        if ($(this).val().length == 0) {
                            error = true;
                            $(this).parent().addClass("has-error");
                            $(this).siblings(".error").fadeIn(500);
                        } else {
                            $(this).parent().removeClass("has-error");
                            $(this).siblings(".error").fadeOut(500);
                        }
                    });

                    if (error == false) {
                        $('#send_message').attr({'disabled': 'true', 'value': 'Sending...'});

                        $.post("includes/email/send_email.php", form.serialize(), function (result) {
                            //Debug - coincides with the debug in the email php file
                            //console.log(result);

                            if (result == 'sent') {
                                $('#mail_success_call_back').fadeIn(500);
                            } else {
                                $('#mail_fail_call_back').fadeIn(500);
                                $('#send_message').removeAttr('disabled').attr('value', 'Submit');
                            }
                        });
                    } else {
                        $("#validation_call_back").fadeIn(500);
                    }
                });
            });
        }(jQuery));
    </script>
</section>
<footer>
    <div class="content-container">
        <div class="row">
            <div class="col-md-4">
                <h4>About We Move and Clean</h4>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mattis lectus eu sapien vehicula, et
                    mollis ligula consectetur. Nulla commodo. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Duis
                    mattis lectus eu sapien vehicula, et mollis ligula consectetur. Nulla commodo
                </p>
                <ul class="socialIcons socialIconsFooter">
                    <li><a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a></li>
                    <li><a href="https://plus.google.com/"><i class="fa fa-google-plus"></i></a></li>
                </ul>
            </div>
            <div class="col-md-2">
                <h4>Quick Find</h4>
                <ul class="quickLinks">
                    <li>
                        <a href="">About Us</a>
                    </li>
                    <li>
                        <a href="">Services</a>
                    </li>
                    <li>
                        <a href="">Blog</a>
                    </li>
                    <li>
                        <a href="">Contact Us</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <hr>
            </div>
        </div>
        <div class="row copyright">
            <div class="col-md-6">
                <p>Created By: <a href="http://www.cherry-designs.net/" target="_blank">Cherry Designs</a></p>
            </div>
            <div class="col-md-6 floatRight">
                <ul class="footerLinks">
                    <li><a href="termsandconditions.php">Terms and Conditions</a></li>
                    <li><a href="privacypolicy.php">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>
<script src="js/app.js"></script>
</div>
</body>
</html>