(function($) {
    $(document).ready(function() {
       $(".btn[data-toggle='collapse']").click(function(e) {
           e.preventDefault();
           var $content = $(this).attr("href");
           var $collapse = $($content);
           $collapse.collapse("toggle");
       });
    });
}(jQuery));