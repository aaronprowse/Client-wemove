<?php
global $page_title, $page_link;
$page_title = "Clearance Services";
$page_link = basename(__FILE__);
include_once('includes/header.php');
?>
    <main>
        <div class="sr-only"><h1>Services</h1></div>

        <section class="banner-container">
            <div id="homeSlider" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#homeSlider" data-slide-to="0" class="active"></li>
                    <li data-target="#homeSlider" data-slide-to="1"></li>
                    <li data-target="#homeSlider" data-slide-to="2"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <a href="#">
                            <img src="images/slider/we-move-and-clean-slider-2.jpg" class="img-responsive respond">
                        </a>
                    </div>
                    <div class="item">
                        <a href="#">
                            <img src="images/slider/we-move-and-clean-slider-1.jpg" class="img-responsive respond">
                        </a>
                    </div>
                </div>

                <!-- Left and right controls -->
                <a class="left carousel-control" href="#homeSlider" role="button" data-slide="prev">
                    <i class="fa fa-angle-left"></i>
                </a>
                <a class="right carousel-control" href="#homeSlider" role="button" data-slide="next">
                    <i class="fa fa-angle-right"></i>
                </a>
            </div>
        </section>

        <section class="content-container">
            <div class="row">
                <div class="col-md-6">
                    <img src="http://placehold.it/450x350" class="img-responsive respond"
                         alt="We Move & Clean - Service">
                </div>
                <div class="col-md-6">

                    <div>

                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active"><a href="#house" aria-controls="house" role="tab"
                                                                      data-toggle="tab">House</a></li>
                            <li role="presentation"><a href="#office" aria-controls="office" role="tab"
                                                       data-toggle="tab">Office</a></li>
                            <li role="presentation"><a href="#rubbish" aria-controls="rubbish" role="tab"
                                                       data-toggle="tab">Rubbish</a></li>
                        </ul>


                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane fade in active" id="house">
                                <p><strong>House</strong> Pellentesque habitant morbi tristique senectus sed netus males uada fames
                                    ac turpis egestas aenu
                                    ean non tell Donec pede qua placerat ristique faucibus poserw ulet elobortis
                                    justo.<br/><br/>

                                    Etiam nunc sit. Fusce non pede non erat varius lacinia unc ligula. Duis euduisemper
                                    ant euismod
                                    viverra. Nam etyw ant etiam sed ipsum.Donec sit amet nis In viverra dolor non justo.
                                    Integer
                                    velit mil facilisis egety volutpat et aliquam sed magna sed non. Lorem ipsum dolor
                                    sit amet
                                    consectetur.</p>

                                <div class="contact-btn">
                                    <a href="#service-collapse" class="btn" data-toggle="collapse">Get A Quote</a>
                                </div>
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="office">
                                <p><strong>Office</strong> Pellentesque habitant morbi tristique senectus sed netus males uada fames
                                    ac turpis egestas aenu
                                    ean non tell Donec pede qua placerat ristique faucibus poserw ulet elobortis
                                    justo.<br/><br/>

                                    Etiam nunc sit. Fusce non pede non erat varius lacinia unc ligula. Duis euduisemper
                                    ant euismod
                                    viverra. Nam etyw ant etiam sed ipsum.Donec sit amet nis In viverra dolor non justo.
                                    Integer
                                    velit mil facilisis egety volutpat et aliquam sed magna sed non. Lorem ipsum dolor
                                    sit amet
                                    consectetur.</p>

                                <div class="contact-btn">
                                    <a href="#service-collapse" class="btn" data-toggle="collapse">Get A Quote</a>
                                </div>
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="rubbish">
                                <p><strong>Rubbish</strong> Pellentesque habitant morbi tristique senectus sed netus males uada fames
                                    ac turpis egestas aenu
                                    ean non tell Donec pede qua placerat ristique faucibus poserw ulet elobortis
                                    justo.<br/><br/>

                                    Etiam nunc sit. Fusce non pede non erat varius lacinia unc ligula. Duis euduisemper
                                    ant euismod
                                    viverra. Nam etyw ant etiam sed ipsum.Donec sit amet nis In viverra dolor non justo.
                                    Integer
                                    velit mil facilisis egety volutpat et aliquam sed magna sed non. Lorem ipsum dolor
                                    sit amet
                                    consectetur.</p>

                                <div class="contact-btn">
                                    <a href="#service-collapse" class="btn" data-toggle="collapse">Get A Quote</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="content-container collapse" id="service-collapse">
            <form id="contact_form" method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6">
                        <div class="serviceFormBox">
                            <div class="serviceFormBox__title">
                                <h3><span class="greenIcon"><i class="fa fa-calendar"></i></span>Date</h3>
                            </div>
                            <div class="serviceFormBox__content">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>From</label>
                                            <input type="date" class="form-control required" id="from_date" name="from_date">
                                            <span id="from_date_error" class="error">From date is required</span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>To</label>
                                            <input type="date" class="form-control required" id="to_date" name="to_date">
                                            <span id="to_date_error" class="error">To date is required</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="serviceFormBox">
                            <div class="serviceFormBox__title">
                                <h3><span class="greenIcon"><i class="fa fa-calendar"></i></span>Time</h3>
                            </div>
                            <div class="serviceFormBox__content">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>From</label>
                                            <select class="form-control" id="from_time" name="from_time">
                                                <option value="6.00">6.00</option>
                                                <option value="6.30">6.30</option>
                                                <option value="7.00">7.00</option>
                                                <option value="7.30">7.30</option>
                                                <option value="8.00">8.00</option>
                                                <option value="8.30">8.30</option>
                                                <option value="9.00">9.00</option>
                                                <option value="9.30">9.30</option>
                                                <option value="10.00">10.00</option>
                                                <option value="10.30">10.30</option>
                                                <option value="11.00">11.00</option>
                                                <option value="11.30">11.30</option>
                                                <option value="12.00">12.00</option>
                                                <option value="12.30">12.30</option>
                                                <option value="13.00">13.00</option>
                                                <option value="13.30">13.30</option>
                                                <option value="14.00">14.00</option>
                                                <option value="14.30">14.30</option>
                                                <option value="15.00">15.00</option>
                                                <option value="15.30">15.30</option>
                                                <option value="16.00">16.00</option>
                                                <option value="16.30">16.30</option>
                                                <option value="17.00">17.00</option>
                                                <option value="17.30">17.30</option>
                                                <option value="18.00">18.00</option>
                                                <option value="18.30">18.30</option>
                                                <option value="19.00">19.00</option>
                                                <option value="19.30">19.30</option>
                                                <option value="20.00">20.00</option>
                                                <option value="20.30">20.30</option>
                                                <option value="21.00">21.00</option>
                                                <option value="21.30">21.30</option>
                                                <option value="22.00">22.00</option>
                                                <option value="22.30">22.30</option>
                                                <option value="23.00">23.00</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>To</label>
                                            <select class="form-control" id="to_time" name="to_time">
                                                <option value="6.00">6.00</option>
                                                <option value="6.30">6.30</option>
                                                <option value="7.00">7.00</option>
                                                <option value="7.30">7.30</option>
                                                <option value="8.00">8.00</option>
                                                <option value="8.30">8.30</option>
                                                <option value="9.00">9.00</option>
                                                <option value="9.30">9.30</option>
                                                <option value="10.00">10.00</option>
                                                <option value="10.30">10.30</option>
                                                <option value="11.00">11.00</option>
                                                <option value="11.30">11.30</option>
                                                <option value="12.00">12.00</option>
                                                <option value="12.30">12.30</option>
                                                <option value="13.00">13.00</option>
                                                <option value="13.30">13.30</option>
                                                <option value="14.00">14.00</option>
                                                <option value="14.30">14.30</option>
                                                <option value="15.00">15.00</option>
                                                <option value="15.30">15.30</option>
                                                <option value="16.00">16.00</option>
                                                <option value="16.30">16.30</option>
                                                <option value="17.00">17.00</option>
                                                <option value="17.30">17.30</option>
                                                <option value="18.00">18.00</option>
                                                <option value="18.30">18.30</option>
                                                <option value="19.00">19.00</option>
                                                <option value="19.30">19.30</option>
                                                <option value="20.00">20.00</option>
                                                <option value="20.30">20.30</option>
                                                <option value="21.00">21.00</option>
                                                <option value="21.30">21.30</option>
                                                <option value="22.00">22.00</option>
                                                <option value="22.30">22.30</option>
                                                <option value="23.00">23.00</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="serviceFormBox">
                            <div class="serviceFormBox__title">
                                <h3><span class="greenIcon"><i class="fa fa-user"></i></span>Personal Info</h3>
                            </div>
                            <div class="serviceFormBox__content">
                                <div class="row">
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Title</label>
                                            <select class="form-control valid" id="title" name="title">
                                                <option value="Mr">Mr</option>
                                                <option value="Mrs">Mrs</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Name</label>
                                            <input type="text" class="form-control" id="name" name="name">
                                            <span id="name_error" class="error">Name is required</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Email <span class="red">*</span></label>
                                            <input type="text" class="form-control required" id="email" name="email">
                                            <span id="email_error" class="error">Email is required</span>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Contact Number</label>
                                            <input type="text" class="form-control" id="contact_number"
                                                   name="contact_number">
                                            <span id="contact_number_error"
                                                  class="error">Contact Number is required</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="serviceFormBox">
                            <div class="serviceFormBox__title">
                                <h3><span class="greenIcon"><i class="fa fa-truck"></i></span>Collection Info</h3>
                            </div>
                            <div class="serviceFormBox__content">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Property number and street name</label>
                                            <input type="text" class="form-control" id="pty_number" name="pty_number">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Postcode <span class="red">*</span></label>
                                            <input type="text" class="form-control required" id="postcode" name="postcode">
                                            <span id="postcode_error" class="error">Postcode is required</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="serviceFormBox">
                            <div class="serviceFormBox__title">
                                <h3><span class="greenIcon"><i class="fa fa-wrench"></i></span>Description</h3>
                            </div>
                            <div class="serviceFormBox__content">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="dispose_of">Please describe the items / rubbish you would like to dispose of</label>
                                            <textarea id="dispose_of" name="dispose_of" class="form-control"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="size_of_load">Approximate size of the load <span class="red">*</span></label>
                                            <select class="form-control required" id="size_of_load" name="size_of_load">
                                                <option value="">-- Select --</option>
                                                <option value="5 cubic yards">5 cubic yards</option>
                                                <option value="7 cubic yards">7 cubic yards</option>
                                                <option value="10 cubic yards">10 cubic yards</option>
                                            </select>
                                            <span class="error">Size of load is required</span>
                                            <p><em>Please note that 1 cubic yard is about the same size as 2 wheelie bins or standard domestic fridge-freezer</em></p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="waste_contained">How is the waste contained? <span class="red">*</span></label>
                                            <select class="form-control required" id="waste_contained" name="waste_contained">
                                                <option value="">-- Select --</option>
                                                <option value="Loose">Loose</option>
                                                <option value="Sacks">Sacks</option>
                                                <option value="Other">Other</option>
                                            </select>
                                            <span class="error">How the waste is contained is required</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="serviceFormBox">
                            <div class="serviceFormBox__title">
                                <h3><span class="greenIcon"><i class="fa fa-truck"></i></span>Parking</h3>
                            </div>
                            <div class="serviceFormBox__content">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="parking">Parking <span class="red">*</span></label>
                                            <select class="form-control required" id="parking" name="parking">
                                                <option value="">-- Select --</option>
                                                <option value="Driveway">Driveway</option>
                                                <option value="Street Same Side">Street (same side as property)</option>
                                                <option value="Street Opposite Side">Street (opposite side of property)</option>
                                            </select>
                                            <span class="error">Parking is required</span>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="distance_from_load">Distance from the load <span class="red">*</span></label>
                                            <select class="form-control required" id="distance_from_load" name="distance_from_load">
                                                <option value="">-- Select --</option>
                                                <option value="Less than 16 feet (5 meters)">Less than 16 feet (5 meters)</option>
                                                <option value="Less than 50 feet (15 meters)">Less than 50 feet (15 meters)</option>
                                                <option value="Less than 100 feet (30 meters)">Less than 100 feet (30 meters)</option>
                                            </select>
                                            <span class="error">Distance from load is required</span>
                                        </div>
                                    </div>
                                    <div class="col-md-1"></div>
                                    <div class="col-md-5">
                                        <label for="load_location">Location of the load <span class="red">*</span></label>
                                        <select class="form-control required" id="load_location" name="load_location">
                                            <option value="">-- Select --</option>
                                            <option value="Inside (downstairs)">Inside (downstairs)</option>
                                            <option value="Inside (upstairs)">Inside (upstairs)</option>
                                            <option value="Outside (front garden / yard)">Outside (front garden / yard)</option>
                                            <option value="Outside (back garden / yard)">Outside (back garden / yard)</option>
                                            <option value="All over the place">All over the place</option>
                                            <option value="Somewhere else (please specify below)">Somewhere else (please specify below)</option>
                                        </select>
                                        <span class="error">Location of load is required</span>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <span class="pull-left">I will arrange parking space for "We Move and Clean" staff</span>
                                            <div class="pull-right">
                                                <input type="checkbox" class="toggle" id="parking_for_staff" name="parking_for_staff">
                                                <label for="parking_for_staff"><span>Yes</span><span>No</span></label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="parking_comments">Additional Comments</label>
                                        <textarea id="parking_comments" name="parking_comments" class="form-control"></textarea>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p>(Resident's Parking Scheme - a temporary permit must be provided)</p>
                                        <p>(Pay and Display Parking - parking charge will be added to the final bill)</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="serviceFormBox">
                            <div class="serviceFormBox__title">
                                <h3><span class="greenIcon"><i class="fa fa-plus"></i></span>Additional Information</h3>
                            </div>
                            <div class="serviceFormBox__content">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="additional_message">Write your notes or message</label>
                                            <textarea id="additional_message" name="additional_message"
                                                      class="form-control"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <span id="mail_success" class="success">Message Sent!</span>
                        <span id="mail_fail" class="error">Message failed to send. Contact the system administrator.</span>
                        <span id="validation" class="error">Validation error. Please check your entries.</span>
                        <button type="submit" class="btn btn--green" id="send_message">Submit</button>
                    </div>
                </div>
            </form>
            <script type="text/javascript">
                (function ($) {
                    $(document).ready(function () {
                        $('#send_message').click(function (e) {

                            e.preventDefault();

                            $('#mail_success').fadeOut(500);
                            $('#mail_fail').fadeOut(500);
                            $('#validation').fadeOut(500);
                            
                            var error = false;
                            var form = $("#contact_form");

                            //Error messages
                            form.find("input.required, textarea.required, select.required").each(function() {
                                if ($(this).val().length == 0) {
                                    error = true;
                                    $(this).parent().addClass("has-error");
                                    $(this).siblings(".error").fadeIn(500);
                                } else {
                                    $(this).parent().removeClass("has-error");
                                    $(this).siblings(".error").fadeOut(500);
                                }
                            });

                            if (error == false) {
                                $('#send_message').attr({'disabled': 'true', 'value': 'Sending...'});

                                $.post("includes/email/send_email.php", form.serialize(), function (result) {
                                    //Debug - coincides with the debug in the email php file
                                    //console.log(result);

                                    if (result == 'sent') {
                                        $('#mail_success').fadeIn(500);
                                    } else {
                                        $('#mail_fail').fadeIn(500);
                                        $('#send_message').removeAttr('disabled').attr('value', 'Submit');
                                    }
                                });
                            } else {
                                $("#validation").fadeIn(500);
                            }
                        });
                    });
                }(jQuery));
            </script>
        </section>

        <section class="content-container">
            <div class="row">
                <div class="col-md-6">
                    <img src="http://placehold.it/450x350" class="img-responsive respond"
                         alt="We Move & Clean - Service">
                </div>
                <div class="col-md-6">
                    <img src="http://placehold.it/450x170" class="img-responsive respond"
                         alt="We Move & Clean - Service">
                    <br/>
                    <img src="http://placehold.it/450x170" class="img-responsive respond"
                         alt="We Move & Clean - Service">
                </div>
            </div>
        </section>

        <section class="content-container">
            <h2>What Our Clients Say</h2>
            <div id="testimonials" class="carousel carousel--testimonials slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#testimonials" data-slide-to="0" class="active"></li>
                    <li data-target="#testimonials" data-slide-to="1"></li>
                    <li data-target="#testimonials" data-slide-to="2"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <p>
                            Mauris purus elit, vestibulum ut tellus sit amet, laoreet ultrices arcu. Mauris vehicula
                            magna id diam pellentesque vulputate vel vel ligula. Sed felis justo, blandit ac fringilla
                            nec, laoreet nec diam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
                            posuere cubilia Curae; Proin in suscipit odio, id fermentum elit. Etiam mattis dui nec nibh
                            mollis dignissim. Donec id dignissim lectus, et blandit tortor. Pellentesque sed pulvinar
                            dui.
                        </p>
                    </div>
                    <div class="item">
                        <p>
                            Mauris purus elit, vestibulum ut tellus sit amet, laoreet ultrices arcu. Mauris vehicula
                            magna id diam pellentesque vulputate vel vel ligula. Sed felis justo, blandit ac fringilla
                            nec, laoreet nec diam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
                            posuere cubilia Curae; Proin in suscipit odio, id fermentum elit. Etiam mattis dui nec nibh
                            mollis dignissim. Donec id dignissim lectus, et blandit tortor. Pellentesque sed pulvinar
                            dui.
                        </p>
                    </div>
                    <div class="item">
                        <p>
                            Mauris purus elit, vestibulum ut tellus sit amet, laoreet ultrices arcu. Mauris vehicula
                            magna id diam pellentesque vulputate vel vel ligula. Sed felis justo, blandit ac fringilla
                            nec, laoreet nec diam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
                            posuere cubilia Curae; Proin in suscipit odio, id fermentum elit. Etiam mattis dui nec nibh
                            mollis dignissim. Donec id dignissim lectus, et blandit tortor. Pellentesque sed pulvinar
                            dui.
                        </p>
                    </div>
                    <div class="item">
                        <p>
                            Mauris purus elit, vestibulum ut tellus sit amet, laoreet ultrices arcu. Mauris vehicula
                            magna id diam pellentesque vulputate vel vel ligula. Sed felis justo, blandit ac fringilla
                            nec, laoreet nec diam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
                            posuere cubilia Curae; Proin in suscipit odio, id fermentum elit. Etiam mattis dui nec nibh
                            mollis dignissim. Donec id dignissim lectus, et blandit tortor. Pellentesque sed pulvinar
                            dui.
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <section class="content-container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="underline">Latest News</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4">
                    <article>
                        <h3>Article</h3>
                        <img src="images/we-move-and-clean-blog-image.png" class="img-responsive">
                        <p>
                            Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit.
                            Sed vel interdum eros. Nunc laoreet sem hendrerit diam congue, ut sagittis felis porta.
                            Proin id
                            euismod nibh, et blandit lacus. Etiam eu eros nec nunc faucibus dignissim. Aliquam congue
                            quis
                            mi eu vestibulum. Vestibulum finibus nibh et ex sodales tincidunt. Mauris dictum leo velit,
                            nec
                            condimentum sapien ornare eget.
                        </p>
                        <div class="link">
                            <a href="#">Read More</a>
                        </div>
                    </article>
                </div>
                <div class="col-md-4">
                    <article>
                        <h3>Article</h3>
                        <img src="images/we-move-and-clean-blog-image.png" class="img-responsive">
                        <p>
                            Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit.
                            Sed vel interdum eros. Nunc laoreet sem hendrerit diam congue, ut sagittis felis porta.
                            Proin id
                            euismod nibh, et blandit lacus. Etiam eu eros nec nunc faucibus dignissim. Aliquam congue
                            quis
                            mi eu vestibulum. Vestibulum finibus nibh et ex sodales tincidunt. Mauris dictum leo velit,
                            nec
                            condimentum sapien ornare eget.
                        </p>
                        <div class="link">
                            <a href="#">Read More</a>
                        </div>
                    </article>
                </div>
                <div class="col-md-4">
                    <article>
                        <h3>Article</h3>
                        <img src="images/we-move-and-clean-blog-image.png" class="img-responsive">
                        <p>
                            Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit.
                            Sed vel interdum eros. Nunc laoreet sem hendrerit diam congue, ut sagittis felis porta.
                            Proin id
                            euismod nibh, et blandit lacus. Etiam eu eros nec nunc faucibus dignissim. Aliquam congue
                            quis
                            mi eu vestibulum. Vestibulum finibus nibh et ex sodales tincidunt. Mauris dictum leo velit,
                            nec
                            condimentum sapien ornare eget.
                        </p>
                        <div class="link">
                            <a href="#">Read More</a>
                        </div>
                    </article>
                </div>
            </div>
        </section>
    </main>
<?php
include_once('includes/footer.php');
?>