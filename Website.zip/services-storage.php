<?php
global $page_title, $page_link;
$page_title = "Storage Services";
$page_link = basename(__FILE__);
include_once('includes/header.php');
?>
    <main>
        <div class="sr-only"><h1>Services</h1></div>

        <section class="banner-container">
            <div id="homeSlider" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#homeSlider" data-slide-to="0" class="active"></li>
                    <li data-target="#homeSlider" data-slide-to="1"></li>
                    <li data-target="#homeSlider" data-slide-to="2"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <a href="#">
                            <img src="images/slider/we-move-and-clean-slider-2.jpg" class="img-responsive respond">
                        </a>
                    </div>
                    <div class="item">
                        <a href="#">
                            <img src="images/slider/we-move-and-clean-slider-1.jpg" class="img-responsive respond">
                        </a>
                    </div>
                </div>

                <!-- Left and right controls -->
                <a class="left carousel-control" href="#homeSlider" role="button" data-slide="prev">
                    <i class="fa fa-angle-left"></i>
                </a>
                <a class="right carousel-control" href="#homeSlider" role="button" data-slide="next">
                    <i class="fa fa-angle-right"></i>
                </a>
            </div>
        </section>

        <section class="content-container">
            <div class="row">
                <div class="col-md-6">
                    <img src="http://placehold.it/450x350" class="img-responsive respond"
                         alt="We Move & Clean - Service">
                </div>
                <div class="col-md-6">
                                <p><strong>Storage - Coming Soon</strong> Pellentesque habitant morbi tristique senectus sed netus males uada fames
                                    ac turpis egestas aenu
                                    ean non tell Donec pede qua placerat ristique faucibus poserw ulet elobortis
                                    justo.<br/><br/>

                                    Etiam nunc sit. Fusce non pede non erat varius lacinia unc ligula. Duis euduisemper
                                    ant euismod
                                    viverra. Nam etyw ant etiam sed ipsum.Donec sit amet nis In viverra dolor non justo.
                                    Integer
                                    velit mil facilisis egety volutpat et aliquam sed magna sed non. Lorem ipsum dolor
                                    sit amet
                                    consectetur.</p>
                </div>
            </div>
        </section>


        <section class="content-container">
            <div class="row">
                <div class="col-md-6">
                    <img src="http://placehold.it/450x350" class="img-responsive respond"
                         alt="We Move & Clean - Service">
                </div>
                <div class="col-md-6">
                    <img src="http://placehold.it/450x170" class="img-responsive respond"
                         alt="We Move & Clean - Service">
                    <br/>
                    <img src="http://placehold.it/450x170" class="img-responsive respond"
                         alt="We Move & Clean - Service">
                </div>
            </div>
        </section>

        <section class="content-container">
            <h2>What Our Clients Say</h2>
            <div id="testimonials" class="carousel carousel--testimonials slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#testimonials" data-slide-to="0" class="active"></li>
                    <li data-target="#testimonials" data-slide-to="1"></li>
                    <li data-target="#testimonials" data-slide-to="2"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <p>
                            Mauris purus elit, vestibulum ut tellus sit amet, laoreet ultrices arcu. Mauris vehicula
                            magna id diam pellentesque vulputate vel vel ligula. Sed felis justo, blandit ac fringilla
                            nec, laoreet nec diam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
                            posuere cubilia Curae; Proin in suscipit odio, id fermentum elit. Etiam mattis dui nec nibh
                            mollis dignissim. Donec id dignissim lectus, et blandit tortor. Pellentesque sed pulvinar
                            dui.
                        </p>
                    </div>
                    <div class="item">
                        <p>
                            Mauris purus elit, vestibulum ut tellus sit amet, laoreet ultrices arcu. Mauris vehicula
                            magna id diam pellentesque vulputate vel vel ligula. Sed felis justo, blandit ac fringilla
                            nec, laoreet nec diam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
                            posuere cubilia Curae; Proin in suscipit odio, id fermentum elit. Etiam mattis dui nec nibh
                            mollis dignissim. Donec id dignissim lectus, et blandit tortor. Pellentesque sed pulvinar
                            dui.
                        </p>
                    </div>
                    <div class="item">
                        <p>
                            Mauris purus elit, vestibulum ut tellus sit amet, laoreet ultrices arcu. Mauris vehicula
                            magna id diam pellentesque vulputate vel vel ligula. Sed felis justo, blandit ac fringilla
                            nec, laoreet nec diam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
                            posuere cubilia Curae; Proin in suscipit odio, id fermentum elit. Etiam mattis dui nec nibh
                            mollis dignissim. Donec id dignissim lectus, et blandit tortor. Pellentesque sed pulvinar
                            dui.
                        </p>
                    </div>
                    <div class="item">
                        <p>
                            Mauris purus elit, vestibulum ut tellus sit amet, laoreet ultrices arcu. Mauris vehicula
                            magna id diam pellentesque vulputate vel vel ligula. Sed felis justo, blandit ac fringilla
                            nec, laoreet nec diam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
                            posuere cubilia Curae; Proin in suscipit odio, id fermentum elit. Etiam mattis dui nec nibh
                            mollis dignissim. Donec id dignissim lectus, et blandit tortor. Pellentesque sed pulvinar
                            dui.
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <section class="content-container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="underline">Latest News</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4">
                    <article>
                        <h3>Article</h3>
                        <img src="images/we-move-and-clean-blog-image.png" class="img-responsive">
                        <p>
                            Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit.
                            Sed vel interdum eros. Nunc laoreet sem hendrerit diam congue, ut sagittis felis porta.
                            Proin id
                            euismod nibh, et blandit lacus. Etiam eu eros nec nunc faucibus dignissim. Aliquam congue
                            quis
                            mi eu vestibulum. Vestibulum finibus nibh et ex sodales tincidunt. Mauris dictum leo velit,
                            nec
                            condimentum sapien ornare eget.
                        </p>
                        <div class="link">
                            <a href="#">Read More</a>
                        </div>
                    </article>
                </div>
                <div class="col-md-4">
                    <article>
                        <h3>Article</h3>
                        <img src="images/we-move-and-clean-blog-image.png" class="img-responsive">
                        <p>
                            Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit.
                            Sed vel interdum eros. Nunc laoreet sem hendrerit diam congue, ut sagittis felis porta.
                            Proin id
                            euismod nibh, et blandit lacus. Etiam eu eros nec nunc faucibus dignissim. Aliquam congue
                            quis
                            mi eu vestibulum. Vestibulum finibus nibh et ex sodales tincidunt. Mauris dictum leo velit,
                            nec
                            condimentum sapien ornare eget.
                        </p>
                        <div class="link">
                            <a href="#">Read More</a>
                        </div>
                    </article>
                </div>
                <div class="col-md-4">
                    <article>
                        <h3>Article</h3>
                        <img src="images/we-move-and-clean-blog-image.png" class="img-responsive">
                        <p>
                            Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit.
                            Sed vel interdum eros. Nunc laoreet sem hendrerit diam congue, ut sagittis felis porta.
                            Proin id
                            euismod nibh, et blandit lacus. Etiam eu eros nec nunc faucibus dignissim. Aliquam congue
                            quis
                            mi eu vestibulum. Vestibulum finibus nibh et ex sodales tincidunt. Mauris dictum leo velit,
                            nec
                            condimentum sapien ornare eget.
                        </p>
                        <div class="link">
                            <a href="#">Read More</a>
                        </div>
                    </article>
                </div>
            </div>
        </section>
    </main>
<?php
include_once('includes/footer.php');
?>