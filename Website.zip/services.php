<?php
global $page_title, $page_link;
$page_title = "Services";
$page_link = basename(__FILE__);
include_once('includes/header.php');
?>
    <main>
        <div class="sr-only"><h1>Services</h1></div>

        <section class="banner-container">
            <div id="homeSlider" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#homeSlider" data-slide-to="0" class="active"></li>
                    <li data-target="#homeSlider" data-slide-to="1"></li>
                    <li data-target="#homeSlider" data-slide-to="2"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <a href="#">
                            <img src="images/slider/we-move-and-clean-slider-2.jpg" class="img-responsive respond">
                        </a>
                    </div>
                    <div class="item">
                        <a href="#">
                            <img src="images/slider/we-move-and-clean-slider-1.jpg" class="img-responsive respond">
                        </a>
                    </div>
                </div>

                <!-- Left and right controls -->
                <a class="left carousel-control" href="#homeSlider" role="button" data-slide="prev">
                    <i class="fa fa-angle-left"></i>
                </a>
                <a class="right carousel-control" href="#homeSlider" role="button" data-slide="next">
                    <i class="fa fa-angle-right"></i>
                </a>
            </div>
        </section>

        <section class="content-container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="underline">Our Services</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pharetra diam id aliquet commodo.
                        Nam
                        nec
                        sapien
                        metus. Aenean quam mauris, tincidunt quis commodo at, pharetra at nisl. Fusce cursus arcu a
                        risus
                        lobortis,
                        vitae ultricies nisi rhoncus. Donec scelerisque, neque eu rhoncus bibendum, odio urna commodo
                        dolor,
                        eu
                        ornare mauris metus eget sem. Integer imperdiet leo non enim consectetur, vel commodo tortor
                        luctus.
                        Nunc ac
                        felis maximus, tincidunt sapien non, placerat magna. Quisque ut mauris sit amet ante feugiat
                        laoreet
                        eget
                        non ligula. Praesent maximus varius urna, ut pulvinar massa pellentesque et. Pellentesque
                        egestas
                        porta
                        aliquam. Nunc ut consectetur ex.
                    </p>
                </div>
                <div class="col-md-6">
                    <p class="alt right">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pharetra diam id aliquet commodo.
                        Nam
                        nec
                        sapien metus. Aenean quam mauris, tincidunt quis commodo at, pharetra at nisl. Fusce cursus arcu
                        a
                        risus
                        lobortis, vitae ultricies nisi rhoncus. Donec scelerisque, neque eu rhoncus bibendum, odio urna
                        commodo
                        dolor, eu ornare mauris metus eget sem. Integer imperdiet leo non enim consectetur, vel commodo
                        tortor
                        luctus. Nunc ac felis maximus, tincidunt sapien non, placerat magna. Quisque ut mauris sit amet
                        ante
                        feugiat laoreet eget non ligula. Praesent maximus varius urna, ut pulvinar massa pellentesque
                        et.
                        Pellentesque egestas porta aliquam. Nunc ut consectetur ex.
                    </p>
                </div>
            </div>
        </section>

        <section class="content-container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="underline">Our Services</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="serviceTile">
                        <a href="services-removals.php">
                            <div class="serviceTile__image">
                                <img src="images/we-move-and-clean-service-1.jpg" class="img-responsive respond"
                                     alt="We Move & Clean - Removals">
                            </div>
                            <div class="serviceTile__title">
                                <span>Removals</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="serviceTile">
                        <a href="services-cleaning.php">
                            <div class="serviceTile__image">
                                <img src="images/we-move-and-clean-service-2.jpg" class="img-responsive respond"
                                     alt="We Move & Clean - Cleaning">
                            </div>
                            <div class="serviceTile__title">
                                <span>Cleaning</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="serviceTile">
                        <a href="services-clearance.php">
                            <div class="serviceTile__image">
                                <img src="images/we-move-and-clean-service-3.jpg" class="img-responsive respond"
                                     alt="We Move & Clean - Clearance">
                            </div>
                            <div class="serviceTile__title">
                                <span>Clearance</span>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="serviceTile">
                        <a href="services-carpet-cleaning.php">
                            <div class="serviceTile__image">
                                <img src="images/we-move-and-clean-service-4.jpg" class="img-responsive respond"
                                     alt="We Move & Clean - Carpets">
                            </div>
                            <div class="serviceTile__title">
                                <span>Carpets</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="serviceTile">
                        <a href="services-storage.php">
                            <div class="serviceTile__image">
                                <img src="images/we-move-and-clean-service-5.jpg" class="img-responsive respond"
                                     alt="We Move & Clean - Storage">
                            </div>
                            <div class="serviceTile__title">
                                <span>Storage</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="serviceTile">
                        <a href="services-furniture-assembly.php">
                            <div class="serviceTile__image">
                                <img src="images/we-move-and-clean-service-6.jpg" class="img-responsive respond"
                                     alt="We Move & Clean - Assembly">
                            </div>
                            <div class="serviceTile__title">
                                <span>Assembly</span>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="serviceTile">
                        <a href="services-van-with-driver-hire.php">
                            <div class="serviceTile__image">
                                <img src="images/we-move-and-clean-service-4.jpg" class="img-responsive respond"
                                     alt="We Move & Clean - Van & Driver Hire">
                            </div>
                            <div class="serviceTile__title">
                                <span>Van & Driver Hire</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="serviceTile">
                        <a href="services-crate-hire.php">
                            <div class="serviceTile__image">
                                <img src="images/we-move-and-clean-service-5.jpg" class="img-responsive respond"
                                     alt="We Move & Clean - Crate Hire">
                            </div>
                            <div class="serviceTile__title">
                                <span>Crate Hire</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="serviceTile">
                        <a href="services-packing-service.php">
                            <div class="serviceTile__image">
                                <img src="images/we-move-and-clean-service-6.jpg" class="img-responsive respond"
                                     alt="We Move & Clean - Packing Service">
                            </div>
                            <div class="serviceTile__title">
                                <span>Packing Service</span>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>

        <section class="content-container">
            <h2>What Our Clients Say</h2>
            <div id="testimonials" class="carousel carousel--testimonials slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#testimonials" data-slide-to="0" class="active"></li>
                    <li data-target="#testimonials" data-slide-to="1"></li>
                    <li data-target="#testimonials" data-slide-to="2"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <p>
                            Mauris purus elit, vestibulum ut tellus sit amet, laoreet ultrices arcu. Mauris vehicula
                            magna id diam pellentesque vulputate vel vel ligula. Sed felis justo, blandit ac fringilla
                            nec, laoreet nec diam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
                            posuere cubilia Curae; Proin in suscipit odio, id fermentum elit. Etiam mattis dui nec nibh
                            mollis dignissim. Donec id dignissim lectus, et blandit tortor. Pellentesque sed pulvinar
                            dui.
                        </p>
                    </div>
                    <div class="item">
                        <p>
                            Mauris purus elit, vestibulum ut tellus sit amet, laoreet ultrices arcu. Mauris vehicula
                            magna id diam pellentesque vulputate vel vel ligula. Sed felis justo, blandit ac fringilla
                            nec, laoreet nec diam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
                            posuere cubilia Curae; Proin in suscipit odio, id fermentum elit. Etiam mattis dui nec nibh
                            mollis dignissim. Donec id dignissim lectus, et blandit tortor. Pellentesque sed pulvinar
                            dui.
                        </p>
                    </div>
                    <div class="item">
                        <p>
                            Mauris purus elit, vestibulum ut tellus sit amet, laoreet ultrices arcu. Mauris vehicula
                            magna id diam pellentesque vulputate vel vel ligula. Sed felis justo, blandit ac fringilla
                            nec, laoreet nec diam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
                            posuere cubilia Curae; Proin in suscipit odio, id fermentum elit. Etiam mattis dui nec nibh
                            mollis dignissim. Donec id dignissim lectus, et blandit tortor. Pellentesque sed pulvinar
                            dui.
                        </p>
                    </div>
                    <div class="item">
                        <p>
                            Mauris purus elit, vestibulum ut tellus sit amet, laoreet ultrices arcu. Mauris vehicula
                            magna id diam pellentesque vulputate vel vel ligula. Sed felis justo, blandit ac fringilla
                            nec, laoreet nec diam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices
                            posuere cubilia Curae; Proin in suscipit odio, id fermentum elit. Etiam mattis dui nec nibh
                            mollis dignissim. Donec id dignissim lectus, et blandit tortor. Pellentesque sed pulvinar
                            dui.
                        </p>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php
include_once('includes/footer.php');
?>